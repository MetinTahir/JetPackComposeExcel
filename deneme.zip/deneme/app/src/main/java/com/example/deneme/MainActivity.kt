package com.example.deneme

import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.app.ActivityCompat
import com.example.deneme.ui.theme.DenemeTheme
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.PermissionStatus
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.accompanist.permissions.rememberPermissionState
import org.apache.poi.ss.usermodel.WorkbookFactory
import java.io.File
import java.io.FileInputStream


class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DenemeTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    //Greeting()

                    RequestPermission()

                    Log.e("deneme", File(Environment.getExternalStorageDirectory(),"Documents").toString())
                    //readExcelData("/storage/emulated/0/Documents/deneme.xlsx")
                }
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun RequestPermission() {
    val cameraPermissionState = rememberPermissionState(
        android.Manifest.permission.WRITE_EXTERNAL_STORAGE
    )

    when(cameraPermissionState.status){
        is PermissionStatus.Granted -> {

        }
        is PermissionStatus.Denied -> {



        }
    }
}


fun readExcelData(filePath: String) {
    val inputStream = FileInputStream(filePath)
    val workbook = WorkbookFactory.create(inputStream)
    val sheet = workbook.getSheetAt(0) // İlk sayfa

    for (row in sheet) {
        for (cell in row) {
            val cellValue = cell.toString()
            // Veriyi burada işleyebilirsiniz
            println("Cell Value: $cellValue")
        }
    }

    inputStream.close()
}

@Composable
fun Greeting() {
    Image(painter = painterResource(id = R.drawable.ic_launcher_background), contentDescription = "")
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    DenemeTheme {
        Greeting()
    }
}